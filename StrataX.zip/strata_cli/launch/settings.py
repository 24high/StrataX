"""What a launch is made of, as plain data: the choices of the setup screens, the rules that turn them into warnings, and the
flags that say the same thing without the TUI.

No Textual, no network, standard library only: the screens, the flags and the saved presets all use this one description,
so `strata launch --preset X` and clicking through the screens cannot drift apart.

Rules of this file: recommend, never force. A choice that does not fit this computer is a warning with the reason; only
a value that cannot be run at all (a port that is not a number, an unknown access kind) is an error.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import asdict, dataclass, field, fields
from typing import Any

SCHEMA = "strata.launch/1"

#: setup.py's CONTEXTS (kept here only as the fallback when the installer files are not next to this terminal).
FALLBACK_CONTEXTS = (8192, 32768, 65536, 131072, 204800, 262144, 393216, 524288)

ACCESS_KINDS = ("local", "lan", "cloudflare", "tailscale")
ACCESS_WORDS = {"local": "This computer only", "lan": "My local network", "cloudflare": "Cloudflare tunnel",
                "tailscale": "Tailscale"}
TUNE_MODES = ("quick", "thorough", "skip")
VISION_MODES = ("off", "on", "gpu", "cpu")
MTP_MODES = ("on", "off")
KV_MODES = ("int8", "q4_0", "k8v4", "fp16")
DEFAULT_PORT = 8080

#: How many requests the card can answer at once (the spec's "fit to card" default): by graphics memory.
PARALLEL_BY_VRAM = ((32.0, 4), (24.0, 3), (20.0, 2), (0.0, 1))


def fit_parallel(vram_gb: float | None) -> int:
    """12 GB -> 1, 20 -> 2, 24 -> 3, 32 and more -> 4 (each step starts at the listed size)."""
    gb = float(vram_gb or 0.0)
    for floor, n in PARALLEL_BY_VRAM:
        if gb >= floor - 0.5:
            return n
    return 1


def parse_context(text: Any) -> int:
    """`128k`, `128K`, `131072` or `64 K` -> tokens. 1K is 1024 tokens (the engine's and setup's unit)."""
    raw = str(text).strip().lower().replace(" ", "").replace("_", "").replace(",", "")
    m = re.fullmatch(r"(\d+(?:\.\d+)?)(k|m)?", raw)
    if not m:
        raise ValueError(f"'{text}' is not a context size. Use a number of tokens or a size such as 32k, 64k, 128k, 256k.")
    value = float(m.group(1)) * {"k": 1024, "m": 1024 * 1024, None: 1}[m.group(2)]
    n = int(round(value))
    if n < 1024:
        raise ValueError(f"A context of {n} tokens is too small to be useful; the smallest size offered is 8k.")
    return n


def context_label(tokens: int | None) -> str:
    if not tokens:
        return "default"
    if tokens % 1024 == 0:
        return f"{tokens // 1024}K"
    if tokens >= 1000:
        return f"{tokens / 1000:g}K"
    return str(tokens)


def words_for(tokens: int) -> str:
    """About how many English words fit (0.75 words per token, rounded to two figures)."""
    words = tokens * 0.75
    mag = 10 ** max(0, len(str(int(words))) - 2)
    return f"about {int(round(words / mag) * mag):,} words"


@dataclass
class LaunchSettings:
    """Every choice of `strata launch`. `None` means "the recommendation for this computer"."""

    name: str | None = None                    # the saved preset's name
    family: str | None = None                  # catalog family id (qwen, swift, coder, unsloth, gyro, nvfp4...)
    model: str | None = None                   # catalog size (IQ3_XXS ...)
    model_path: str | None = None              # "Use model files I already have": a .gguf file or a folder
    data_dir: str | None = None                # where model files are stored (None: the Strata default)
    gpus: list[int] | None = None              # None = the engine's choice (all usable cards)
    context: int | None = None
    kv: str | None = None                      # None = int8 above 8K, as setup
    vision: str | None = None                  # None = the default (on when the model can read pictures and the engine has the reader), off | on | gpu | cpu
    parallel: int | None = None                # None = fit to the card
    mtp: str | None = None                     # None = as installed (draft layer on); "off" starts without it (less graphics memory and RAM, slower); "on" overrides an installed "off"
    tune: str = "skip"                         # quick | thorough | skip
    tune_allow_small: bool = False             # the "answer-changing" tick, off by default, as in the app
    access: str = "local"
    port: int = DEFAULT_PORT
    api_key: str | None = None                 # never shown whole; stored only in the private preset file
    extra: dict[str, str] = field(default_factory=dict)    # Advanced: --set key=value (flags and STRATA_* variables)
    # filled in by the run, kept in the preset
    tuned_preset: str | None = None            # id of the tuning preset the tuner saved
    tuned_at: str | None = None
    last_used: str | None = None
    created: str | None = None

    def to_dict(self, *, with_key: bool = True) -> dict[str, Any]:
        d = {"schema": SCHEMA, **asdict(self)}
        if not with_key:
            d["api_key"] = "set" if self.api_key else None
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "LaunchSettings":
        known = {f.name for f in fields(cls)}
        clean = {k: v for k, v in (data or {}).items() if k in known}
        if isinstance(clean.get("extra"), dict):
            clean["extra"] = {str(k): str(v) for k, v in clean["extra"].items()}
        else:
            clean.pop("extra", None)
        return cls(**clean)

    def copy(self, **changes: Any) -> "LaunchSettings":
        d = asdict(self)
        d.update(changes)
        return LaunchSettings.from_dict(d)


# ----------------------------------------------------------------------------------------------------- checks

@dataclass
class Notice:
    level: str        # "warn" | "error"
    text: str         # plain words: what it means
    next: str = ""    # plain words: what to do

    def line(self) -> str:
        return self.text + (f" {self.next}" if self.next else "")


def closest(word: str, options: list[str]) -> str | None:
    hit = difflib.get_close_matches(word.lower(), [o.lower() for o in options], n=1, cutoff=0.5)
    if not hit:
        return None
    return next(o for o in options if o.lower() == hit[0])


def check_port(port: Any) -> Notice | None:
    try:
        p = int(port)
    except (TypeError, ValueError):
        return Notice("error", f"'{port}' is not a port number.", "Use a number from 1 to 65535, for example 8080.")
    if not 1 <= p <= 65535:
        return Notice("error", f"Port {p} does not exist.", "Use a number from 1 to 65535, for example 8080.")
    if p < 1024:
        return Notice("warn", f"Port {p} is below 1024; on many computers only an administrator can use it.",
                      "8080 works without special rights.")
    return None


def check_access(s: LaunchSettings) -> list[Notice]:
    out: list[Notice] = []
    if s.access not in ACCESS_KINDS:
        near = closest(s.access, list(ACCESS_KINDS))
        out.append(Notice("error", f"'{s.access}' is not a way to share Strata.",
                          f"Choose one of: {', '.join(ACCESS_KINDS)}." + (f" Did you mean '{near}'?" if near else "")))
        return out
    port = check_port(s.port)
    if port:
        out.append(port)
    if s.access != "local" and not s.api_key:
        out.append(Notice("warn", f"{ACCESS_WORDS[s.access]} without an API key lets anyone who can reach it use your computer's model.",
                          "Add an API key (Strata makes one for you in the Access step)."))
    return out


def check_parallel(s: LaunchSettings, *, vram_gb: float | None, fitted: int | None = None) -> list[Notice]:
    out: list[Notice] = []
    if s.parallel is None:
        return out
    if not 1 <= int(s.parallel) <= 8:
        out.append(Notice("error", f"{s.parallel} requests at once is outside what the engine can do (1 to 8).",
                          "Pick a number from 1 to 8."))
        return out
    fitted = fit_parallel(vram_gb) if fitted is None else fitted
    if vram_gb and s.parallel > fitted:
        out.append(Notice("warn", f"{s.parallel} requests at once is more than a {vram_gb:.0f} GB card usually holds "
                                  f"(it fits {fitted}).",
                          "It can still start; the engine keeps less of the model in graphics memory, so each answer is slower."))
    return out


def check_context(s: LaunchSettings, *, max_fit_tokens: int | None = None) -> list[Notice]:
    out: list[Notice] = []
    if s.context is not None and s.context > 262144:
        out.append(Notice("warn", f"{context_label(s.context)} is more than the model was trained on (256K).",
                          "Setup adds rope scaling for it (experimental); answers may get less reliable."))
    if max_fit_tokens and s.context and s.context > max_fit_tokens:
        out.append(Notice("warn", f"{context_label(s.context)} is bigger than this computer's memory comfortably holds.",
                          f"{context_label(max_fit_tokens)} is the recommended size."))
    return out


# ----------------------------------------------------------------------------------------------------- advanced settings

_ENV_NAME = re.compile(r"^(?=[A-Za-z0-9_]*[A-Z])[A-Za-z_][A-Za-z0-9_]*$")     # any name with a capital letter: STRATA_X, IGC_EnableDPEmulation, ZES_ENABLE_SYSMAN
_FLAG_NAME = re.compile(r"^[a-z][a-z0-9-]*$")


def split_setting(text: str) -> tuple[str, str]:
    """`prefill=65536`, `--prefill=65536`, `STRATA_PIN_BY_NEED=1` -> (key, value); the key is a `--flag` or an ENV name."""
    key, sep, value = text.partition("=")
    key = key.strip()
    if not key:
        raise ValueError("an empty setting name")
    if _ENV_NAME.match(key):
        return key, value.strip()
    flag = key[2:] if key.startswith("--") else key
    flag = flag.replace("_", "-")
    if not _FLAG_NAME.match(flag):
        raise ValueError(f"'{text}' is not a setting name. Write it like prefill=65536 or STRATA_PIN_BY_NEED=1.")
    return "--" + flag, value.strip()


def settings_from_pairs(pairs: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for p in pairs or []:
        k, v = split_setting(p)
        out[k] = v
    return out


def as_argv_changes(extra: dict[str, str], bool_flags: frozenset[str]) -> tuple[dict[str, Any], dict[str, str | None]]:
    """Turn the Advanced table's values into `tune_knobs.apply_to_argv` changes and environment changes.

    A flag without a value (or on/true/yes) is "present"; off/false/no/none removes it; anything else is a value."""
    args: dict[str, Any] = {}
    env: dict[str, str | None] = {}
    for key, value in extra.items():
        if key.startswith("--"):
            low = value.lower()
            if key in bool_flags or low in ("on", "true", "yes", ""):
                args[key] = None if low in ("off", "false", "no", "none") else True
            elif low in ("off", "false", "no", "none"):
                args[key] = None
            else:
                args[key] = value
        else:
            env[key] = None if value.lower() in ("off", "unset", "none") else value
    return args, env


def flags_text(s: LaunchSettings, *, preset: str | None = None) -> str:
    """The `strata launch ...` line that says the same as these choices (copyable)."""
    parts = ["strata launch"]
    if preset:
        parts.append(f'--preset "{preset}"')
    else:
        if s.model_path:
            parts.append(f'--model-path "{s.model_path}"')
        elif s.model:
            parts.append(f"--model {s.model.lower()}" + (f" --family {s.family}" if s.family and s.family != "qwen" else ""))
        if s.data_dir:
            parts.append(f'--data-dir "{s.data_dir}"')
        if s.context:
            parts.append(f"--context {context_label(s.context).lower()}")
        if s.kv:
            parts.append(f"--kv {s.kv}")
        if s.vision:
            parts.append(f"--vision {s.vision}")
        if s.parallel:
            parts.append(f"--parallel {s.parallel}")
        if s.mtp:
            parts.append(f"--mtp {s.mtp}")
        parts.append(f"--tune {s.tune}")
        if s.tune_allow_small:
            parts.append("--tune-allow-small")
        parts.append(f"--access {s.access}")
        parts.append(f"--port {s.port}")
        if s.gpus:
            parts.append("--gpu " + ",".join(str(g) for g in s.gpus))
    for k, v in sorted(s.extra.items()):
        parts.append(f"--set {k[2:] if k.startswith('--') else k}={v}" if v else f"--set {k[2:] if k.startswith('--') else k}")
    return " ".join(parts)


def slug(name: str) -> str:
    """A name safe for profile ids and file names: lowercase letters, digits, - and _, starting with a letter."""
    text = re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9_-]+", "-", name.lower())).strip("-_") or "launch"
    if not text[0].isalpha():
        text = "l" + text
    return text[:48]
